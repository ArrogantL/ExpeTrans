# -*- coding: utf-8 -*-
import json
import re
import traceback
from concurrent.futures import ThreadPoolExecutor

import openai
from rank_bm25 import BM25Okapi

from source_select import experience_delete_singlep


def experience_transfer_and_evaluate_singlep_new_multip(nlp, item, chat_create, logger, logger_lock, prompt, insights_item_list, top_n, max_retry=5):
    if len(insights_item_list) == 0:
        return []

    with ThreadPoolExecutor(max_workers=len(insights_item_list)) as executor:
        futures = []
        for t in insights_item_list:
            futures.append(executor.submit(experience_transfer_and_evaluate_singlep_new, prompt, item, chat_create, logger, logger_lock, t, max_retry))
        results = [future.result() for future in futures]
    insights_list = [tt for t in results for tt in t]

    # insights_list = [tt for t in insights_item_list for tt in t["success_experience"]]

    if len(insights_list) <= top_n:
        return insights_list

    # experience_selection_singlep(prompt, item, chat_create, logger, logger_lock, insights_list, top_n, max_retry=20？？这么大才行)

    toked_insights = []
    for t in insights_list:
        toked_insights.append([token.lemma_ for token in nlp(t) if not token.is_stop])
    insights_list = BM25Okapi(toked_insights).get_top_n(item["toked_prompt"], insights_list, n=top_n)

    return insights_list


def experience_selection_singlep(prompt, item, chat_create, logger, logger_lock, insights_li, top_n, max_retry=5):
    is_insselection_prompt = """<Target Question>
%s
<Target Question>

<Candidate Experience>
%s
</Candidate Experience>


Please select the %d pieces of advice from the candidate experiences that you believe would be the most effective in helping you avoid mistakes if provided to you in advance.

""" % (prompt, "\n".join(["- " + t.strip() for t in insights_li]), top_n)

    insights_li_index = set([t.strip() for t in insights_li])
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = None
            assert False
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": is_insselection_prompt}],
                                                log_flag="select_ins retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            json_res = []

            for line in response.split("\n"):
                cur_text = line.strip()
                tmp_li = re.findall("^([0-9]+\.|-|Insight [0-9]+\.|Insight/Strategy [0-9]+\.|Insight [0-9]+:) +([^\s].*)", cur_text)
                assert len(tmp_li) in (0, 1), tmp_li
                if len(tmp_li) == 1:
                    tmp_li = tmp_li[0][1].strip()
                    if len(tmp_li) <= 10:
                        continue
                    json_res.append(tmp_li)

            for t in json_res:
                assert t in insights_li_index

            break
        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = []
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    return json_res


def transfer_and_evaluate_and_delete_singlep(prompt, item, chat_create, logger, logger_lock, insights_item, max_retry=5):
    insights_li = experience_transfer_and_evaluate_singlep_new(prompt, item, chat_create, logger, logger_lock, insights_item, max_retry=max_retry)
    insights_li = experience_delete_singlep(prompt, item, chat_create, logger, logger_lock, insights_li, max_retry=5)
    return insights_li


def experience_transfer_and_evaluate_singlep_new(prompt, item, chat_create, logger, logger_lock, insights_item, max_retry=5):
    target_tmp_info = "<Target Task>\nTask Function: %s\nTask Step:\n%s\n</Target Task>" % (
        item["task_func"], "\n".join(["- " + t.strip() for t in item["task_steps"]]))
    src_tmp_info = "<Source Task>\nTask Function: %s\nTask Step:\n%s\n</Source Task>" % (
        insights_item["task_func"], "\n".join(["- " + t.strip() for t in insights_item["task_steps"]]))
    src_insights_text = "\n".join(["- " + t.strip() for t in insights_item["success_experience"]])

    is_src_task_prompt = """%s

%s

<Experience for the source task>
%s
</Experience for the source task>

Please transfer these experience for the source task to the target task.
""" % (target_tmp_info, src_tmp_info, src_insights_text)
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = None
            assert False
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": is_src_task_prompt}],
                                                log_flag="transfer_1 retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": is_src_task_prompt},
                                                          {"role": "assistant", "content": response},
                                                          {"role": "user", "content": "Be more general and concise. List by points."}],
                                                log_flag="transfer_2 retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            json_res = []

            for line in response.split("\n"):
                cur_text = line.strip()
                tmp_li = re.findall("^([0-9]+\.|-|Insight [0-9]+\.|Insight/Strategy [0-9]+\.|Insight [0-9]+:) +([^\s].*)", cur_text)
                assert len(tmp_li) in (0, 1), tmp_li
                if len(tmp_li) == 1:
                    tmp_li = tmp_li[0][1].strip()
                    if len(tmp_li) <= 10:
                        continue
                    json_res.append(tmp_li)
            assert len(json_res) > 0
            break
        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = []
        except openai.BadRequestError:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = []
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    return json_res
