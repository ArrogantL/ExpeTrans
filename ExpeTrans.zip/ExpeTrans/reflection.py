# -*- coding: utf-8 -*-
import json
import pdb
import re
import traceback
from copy import deepcopy


def experience_revise_with_messages_v2_multip(chat_create, logger, logger_lock, messages_list, revised_time, max_revised_time, max_retry=3):
    all_to_log = []
    all_to_log.append("### revise time %d ###" % (revised_time + 1))
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = []
            break
        try:
            model_type = "gpt-3.5-turbo-0125"
            revise_messages = []
            response = None
            for step_id, mm in enumerate(messages_list):
                if step_id != 0:
                    assert response is not None
                    revise_messages.append({"role": "assistant", "content": response})
                revise_messages.extend(mm)

                if step_id == len(messages_list) - 1:
                    used_messages = revise_messages[-3:]
                else:
                    used_messages = revise_messages

                response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i + revised_time * 100, temperature=1,
                                                    messages=deepcopy(used_messages),
                                                    log_flag="revise-time %d/%d step %d/%d retry %d/%d" % (
                                                        revised_time + 1, max_revised_time, step_id + 1, len(messages_list), i + 1, max_retry),
                                                    return_to_log=True)
                all_to_log.extend(to_log_list)

            json_res = []
            for line in response.split("\n"):
                cur_text = line.strip()

                tmp_li = re.findall("^([0-9]+\.|-|Insight [0-9]+\.|Insight/Strategy [0-9]+\.|Insight [0-9]+:) +([^\s].*)", cur_text)
                assert len(tmp_li) in (0, 1), tmp_li
                if len(tmp_li) == 1:
                    tmp_li = tmp_li[0][1].strip()
                    if len(tmp_li) <= 10:
                        continue
                    json_res.append(tmp_li)
            assert len(json_res) > 0
            break
        except RuntimeError:
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            pdb.set_trace()
            assert False
        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = []
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    return json_res
