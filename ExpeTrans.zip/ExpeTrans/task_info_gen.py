# -*- coding: utf-8 -*-
import json
import re
import traceback


def gen_task_func_multip(chat_create, logger, logger_lock, prompt, max_retry=5):
    gen_task_func_prompt = """Based on the following Task Example, please describe the specific task function, i.e., the detailed goal that the task aims to achieve.
Use the following JSON format to output:
```json
{
"task function": /* a string describing the specific task function */
}
```

< Task Example >
%s
</ Task Example >""" % prompt
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = None
            assert False
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": gen_task_func_prompt}],
                                                log_flag="gen_task_func retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)
            res = re.findall("```json(.*?)```", response, flags=re.S)
            if len(res) == 0:
                res = re.findall(r"(\{.*?})", response, flags=re.S)
            tmp_out = json.loads(res[0])
            json_res = tmp_out["task function"].strip()
            break

        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = None
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    assert type(json_res) is str
    return json_res


def gen_task_steps_multip(chat_create, logger, logger_lock, prompt, max_retry=5):
    gen_task_step_prompt = """Based on the following Task Example, please describe the general steps to solve this task.

< Task Example >
%s
</ Task Example >""" % prompt
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = None
            assert False
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": gen_task_step_prompt}],
                                                log_flag="gen_task_step1 retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": gen_task_step_prompt},
                                                          {"role": "assistant", "content": response},
                                                          {"role": "user", "content": "Be more general and concise. List by points."}],
                                                log_flag="gen_task_step2 retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            json_res = []

            for line in response.split("\n"):
                cur_text = line.strip()
                tmp_li = re.findall("^([0-9]+\.|-|Step [0-9]+\.|General Step [0-9]+\.|step [0-9]+:) +([^\s].*)", cur_text)
                assert len(tmp_li) in (0, 1), tmp_li
                if len(tmp_li) == 1:
                    tmp_li = tmp_li[0][1].strip()
                    if len(tmp_li) <= 10:
                        continue
                    json_res.append(tmp_li)
            assert len(json_res) > 0
            break

        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = None
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    assert json_res is not None
    assert type(json_res) is list or type(json_res) is tuple
    assert len(json_res) > 0
    return json_res
