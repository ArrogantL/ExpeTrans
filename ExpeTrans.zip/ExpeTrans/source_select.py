# -*- coding: utf-8 -*-
import json
import pdb
import re
import traceback
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict

import numpy as np
from datasets import Dataset


def experience_delete_singlep(prompt, item, chat_create, logger, logger_lock, insights_li, max_retry=5):
    is_delete_prompt = """<Target Question>
%s
<Target Question>

<Candidate Experience>
%s
</Candidate Experience>

Note: You can only delete the experiences, not modify their content.
Please remove the candidate experience that you believe will not help you better solve the target question or avoid mistakes, such as:
- Experiences that only apply to a specific situation of the target task
- Experiences that are too vague or have no noticeable effect
- Experiences that are too superficial or that you are already well-acquainted with
- Experiences that are inherently incorrect
- Experiences that you cannot understand or find difficult to implement
- Duplicate experiences

""" % (prompt, "\n".join(["- " + t.strip() for t in insights_li]))

    insights_li_index = set([t.strip() for t in insights_li])
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = None
            assert False
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i, temperature=1,
                                                messages=[{"role": "user", "content": is_delete_prompt}],
                                                log_flag="transfer_3 retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            json_res = []

            for line in response.split("\n"):
                cur_text = line.strip()
                tmp_li = re.findall("^([0-9]+\.|-|Insight [0-9]+\.|Insight/Strategy [0-9]+\.|Insight [0-9]+:) +([^\s].*)", cur_text)
                assert len(tmp_li) in (0, 1), tmp_li
                if len(tmp_li) == 1:
                    tmp_li = tmp_li[0][1].strip()
                    if len(tmp_li) <= 10:
                        continue
                    json_res.append(tmp_li)

            for t in json_res:
                assert t in insights_li_index

            break
        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = []
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    return json_res


def exprience_bm25_select_multip_with_easy_new_formal(chat_create, logger, logger_lock, prompt, item, task_func_bm25, task_steps_bm25,
                                                      task_data_bm25: List[Dict], task_prompt_bm25,
                                                      select_example_num):
    cur_exm_task_id = item["cur_exm_task_id"]
    cur_item_origin_prompt = item["prompt"]

    if type(task_func_bm25) is Dataset:  # note faiss
        assert type(task_func_bm25) == type(task_steps_bm25)

        cur_item_func_vec = item["task_func_vec"]
        _, indices = task_func_bm25.search('vec', cur_item_func_vec, k=len(task_data_bm25))
        func_index = [int(i) for i in indices if i >= 0]
        func_index_score = np.zeros(len(task_data_bm25))
        for tid, t in enumerate(func_index):
            func_index_score[t] = tid + 1

        cur_item_steps_vec = item["task_steps_vec"]
        _, indices = task_steps_bm25.search('vec', cur_item_steps_vec, k=len(task_data_bm25))
        steps_index = [int(i) for i in indices if i >= 0]
        steps_index_score = np.zeros(len(task_data_bm25))
        for tid, t in enumerate(steps_index):
            steps_index_score[t] = tid + 1

    else:

        assert task_func_bm25.corpus_size == task_steps_bm25.corpus_size == len(task_data_bm25)
        # func
        toked_task_func = item["toked_task_func"]
        func_scores = task_func_bm25.get_scores(toked_task_func)

        func_index = np.argsort(func_scores)[::-1]
        func_index_score = np.zeros(len(task_data_bm25))
        for tid, t in enumerate(func_index):
            func_index_score[t] = tid + 1

        # steps
        toked_task_steps = item["toked_task_steps"]
        steps_scores = task_steps_bm25.get_scores(toked_task_steps)

        steps_index = np.argsort(steps_scores)[::-1]
        steps_index_score = np.zeros(len(task_data_bm25))
        for tid, t in enumerate(steps_index):
            steps_index_score[t] = tid + 1

    t1, t2 = func_index_score, steps_index_score
    harmonic_mean = t1 * t2 / (t1 + t2)

    assert len(harmonic_mean) == len(task_data_bm25)
    top_samples = []
    for i in np.argsort(harmonic_mean):
        t = task_data_bm25[i]
        if t["cur_exm_task_id"] != cur_exm_task_id:
            top_samples.append(t)
        if len(top_samples) == select_example_num:
            break


    top_ids = get_src_task_multip(chat_create, logger, logger_lock, item, top_samples)
    top_samples2 = [top_samples[i] for i in top_ids]
    top_insights2 = [t for t in top_samples2 if "is_success" in t and t["is_success"]]


    return top_insights2


def get_src_task_one_by_one_multip(chat_create, logger, logger_lock, item, top_samples, max_retry=5, new_srt_seed=False):
    top_samples = list(filter(lambda x: "is_success" in x and x["is_success"], top_samples))
    if len(top_samples) == 0:
        return []
    with ThreadPoolExecutor(max_workers=len(top_samples)) as executor:
        futures = []
        for t in top_samples:
            futures.append(executor.submit(get_src_task_one_by_one, chat_create, logger, logger_lock, item, t, max_retry, new_srt_seed))
        results = [future.result() for future in futures]
    selected = []

    for t, r in zip(top_samples, results):
        if r:
            selected.append(t)
    return selected


def get_src_task_one_by_one(chat_create, logger, logger_lock, item, candidate_item, max_retry=5, new_srt_seed=False):
    if not ("is_success" in candidate_item and candidate_item["is_success"]):
        return False
    tgt_tmp_info = "<Target Task>\nTask Function: %s\nTask Step:\n%s\n</Target Task>" % (
        item["task_func"], "\n".join(["- " + t.strip() for t in item["task_steps"]]))

    src_tmp_info = "<Candidate Task>\nTask Function: %s\nTask Step:\n%s\nTask Experience:\n%s\n</Candidate Task>" % \
                   (candidate_item["task_func"], "\n".join(["- " + t.strip() for t in candidate_item["task_steps"]]),
                    "\n".join(["- " + t.strip() for t in candidate_item["success_experience"]]))

    is_src_task_prompt = """%s

%s

Please analyze whether the Task Experience of candidate task is suitable for transferring to the target task?
Provide JSON format output at the end of your reply:
```json
{
"Task Experience Transferability": "High/Low/Medium"
}
``` 
""" % (tgt_tmp_info, src_tmp_info)
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = None
            pdb.set_trace()
            assert False
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i + 1000 * int(new_srt_seed), temperature=1,
                                                messages=[{"role": "user", "content": is_src_task_prompt}],
                                                log_flag="select_src retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            res = re.findall("```json(.*?)```", response, flags=re.S)
            if len(res) == 0:
                res = re.findall(r"(\{.*?})", response, flags=re.S)
            tmp_out = json.loads(res[0])
            assert "Task Experience Transferability" in tmp_out
            json_res = tmp_out["Task Experience Transferability"].lower()
            assert json_res in ["high", "low", "medium"]
            break

        except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = None
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    assert json_res in ["high", "low", "medium"]

    return json_res == "high"


def get_src_task_multip(chat_create, logger, logger_lock, item, top_samples, max_retry=20, new_srt_seed=False):
    if len(top_samples) == 0:
        return []
    tmp_info = "<Target Task>\nTask Function: %s\nTask Step:\n%s\n</Target Task>" % (
        item["task_func"], "\n".join(["- " + t.strip() for t in item["task_steps"]]))
    for order_id, t in enumerate(top_samples):
        tmp_info += "\n\n<Candidate Task %d>\nTask Function: %s\nTask Step:\n%s\nTask Experience:\n%s\n</Candidate Task %d>" \
                    % (order_id + 1,
                       t["task_func"], "\n".join(["- " + x.strip() for x in t["task_steps"]]),
                       "\n".join(["- " + x.strip() for x in t["success_experience"]]) if "success_experience" in t and len(
                           t["success_experience"]) != 0 else "No Experience",
                       order_id + 1)

    is_src_task_prompt = """%s

You are an excellent source task selector, able to select source tasks related to the target task from the above candidate tasks.
The experience gained from solving the source task should be transferable to the target task.
Use the following JSON format to output:
```json
{
"selected task ids": [ /* ids of selected source tasks. If there are no suitable source tasks, please return an empty list. */ ]
}
```
""" % tmp_info
    all_to_log = []
    for i in range(max_retry + 1):
        if i == max_retry:
            all_to_log.append("retry too many times")
            json_res = [1]
            break
        try:
            model_type = "gpt-3.5-turbo-0125"
            response, to_log_list = chat_create(model=model_type, max_tokens=4096, seed=1 + i + 1000 * int(new_srt_seed), temperature=1,
                                                messages=[{"role": "user", "content": is_src_task_prompt}],
                                                log_flag="select_src retry %d/%d" % (i + 1, max_retry),
                                                return_to_log=True)
            all_to_log.extend(to_log_list)

            res = re.findall("```json(.*?)```", response, flags=re.S)
            if len(res) == 0:
                res = re.findall(r"(\{.*?})", response, flags=re.S)
            tmp_out = json.loads(res[0])
            assert "selected task ids" in tmp_out
            selected_src_ids = tmp_out["selected task ids"]
            assert type(selected_src_ids) == list
            json_res = [int(str(t).replace("Candidate Task ", "")) for t in selected_src_ids]
            for i in json_res:
                assert 0 <= i - 1 < len(top_samples)
            break

        except (AttributeError, json.decoder.JSONDecodeError, AssertionError, ValueError):
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            json_res = None
        except Exception:
            all_to_log.append("retry %d/%d" % (i + 1, max_retry))
            all_to_log.append(traceback.format_exc())
            with logger_lock:
                for t in all_to_log:
                    logger.info(t)
            assert False
    with logger_lock:
        for t in all_to_log:
            logger.info(t)
    assert type(json_res) is list

    return [i - 1 for i in json_res]
