# -*- coding: utf-8 -*-

from infer import item_parser_with_split_prompt


def gen_exp_use_prompt_hard(prompt_exp_text, question_prompt_text):
    return """%s
Note: I provide you with the following insights that can help you avoid mistakes, and you must carefully refer to these insights:
%s
Let's think step by step.""" % (question_prompt_text, prompt_exp_text) if len(prompt_exp_text) != 0 else question_prompt_text + "\n\nLet's think step by step."


def gen_exp_use_prompt_soft(prompt_exp_text, question_prompt_text):
    if len(prompt_exp_text) == 0:
        return question_prompt_text + "\n\nLet's think step by step."
    return """Note: you may refer to the insights below for guidance that might help you avoid mistakes:
%s

%s
Let's think step by step.
""" % (prompt_exp_text, question_prompt_text)




def build_icl_prompt(ICL_item_list, question_prompt_text, n_shot):
    ICL_texts = []
    for item in ICL_item_list:
        prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)
        prompt = prompt.strip()
        prompt_answer = prompt_answer.strip()
        if prompt in question_prompt_text or question_prompt_text in prompt:
            continue
        cur_icl_text = "%s\nAnswer: %s" % (prompt, prompt_answer)
        ICL_texts.append(cur_icl_text)

    ICL_texts = ICL_texts[:n_shot]

    ICL_texts = "\n\n".join(ICL_texts)
    return ICL_texts + "\n\n" + question_prompt_text
