# -*- coding: utf-8 -*-
import datetime
import itertools
import json
import logging
import os
import random
import threading
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy

import spacy
import torch
from datasets import Dataset
from openai import OpenAI
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
from tqdm import tqdm

from exptransfer import experience_transfer_and_evaluate_singlep_new_multip
from infer import item_parser_with_split_prompt, task_reasoning_with_split_prompt_multip
from prompt_build import gen_exp_use_prompt_hard, gen_exp_use_prompt_soft
from reflection import experience_revise_with_messages_v2_multip
from source_select import exprience_bm25_select_multip_with_easy_new_formal
from task_info_gen import gen_task_steps_multip, gen_task_func_multip
from utils import get_custom_logger

# TODO For reference only. If there is any discrepancy between the description in the paper and the content in the paper, the description in the paper shall prevail.

corpus_file_list = (

)

random.seed(0) # run 3 time to reduce the randomness of scores
# random.seed(1)
# random.seed(2)

LOGDIR = "log/run_seed0"
# LOGDIR = "log/run_seed1"
# LOGDIR = "log/run_seed2"
os.makedirs(LOGDIR, exist_ok=True)
# three

client = OpenAI(
    api_key=None,
    max_retries=2,
    timeout=120  # The API's official auto-retry configuration, including connection errors (e.g., due to network connectivity issues), 408 request timeouts, 409 conflicts, 429 rate limiting, and >=500 internal errors, are all retried
)

corpus = []
used_data_size=10
for file in corpus_file_list:
    tmp_cor = [json.loads(line) for line in open(file, 'r', encoding="utf-8").readlines()]
    random.shuffle(tmp_cor)
    corpus += tmp_cor[:used_data_size]

assert len(corpus) == used_data_size * len(corpus_file_list) , "The dataset size is incorrect."

for item in corpus:
    if "category" not in item:
        assert "origin_dataset_n" in item
        item["category"] = item["origin_dataset_n"]



bar_format = '{l_bar}{bar}{r_bar}\n'
LOGNAME = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
logger = get_custom_logger(log_name=LOGNAME, level=logging.DEBUG)


nlp = spacy.load('en_core_web_trf', disable=["transformer", "parser", "ner"])



logger_lock = threading.Lock()
parallel_duplicate_detection = {}
pdd_lock = threading.Lock()


# fixed func
def chat_create(model, max_tokens, seed, temperature, messages, log_flag="chat_create", return_to_log=False):
    """
    :param model:
                gpt-3.5-turbo-0125
                gpt-4o
    :param max_tokens:
    :param seed:
    :param temperature:
    :param messages:
    :return:
    """
    # model="gpt-4o"

    inputs = {"model": model, "max_tokens": max_tokens, "seed": seed, "temperature": temperature, "messages": messages}

    input_hash = json.dumps(inputs, ensure_ascii=False)
    with pdd_lock:
        if input_hash not in parallel_duplicate_detection:
            parallel_duplicate_detection[input_hash] = threading.Lock()
        target_cur_lock = parallel_duplicate_detection[input_hash]
    target_cur_lock.acquire()

    tmp_inputs = deepcopy(inputs)
    response = client.chat.completions.create(**tmp_inputs)
    json_response = response.model_dump_json()
    json_response = json.loads(json_response)

    response_content = json_response["choices"][0]["message"]["content"]

    tmp_log_toprint = ""
    for mes in messages:
        tmp_log_toprint += "==[%s]==:\n%s\n\n" % (mes["role"], mes["content"])

    to_log_list = []
    with logger_lock:
        to_log_list.append("### API args ###")
        to_log_list.append("model: %s, max_tokens: %d, seed: %d, temperature: %f" % (model, max_tokens, seed, temperature))
        to_log_list.append("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> start %s >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n" % log_flag
                           + tmp_log_toprint
                           + "\n" + "v" * 100 + "\n"
                           + response_content
                           + "\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< end %s <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n" % log_flag)
        to_log_list.append("### End API ###")

    target_cur_lock.release()
    with pdd_lock:
        if input_hash in parallel_duplicate_detection:
            parallel_duplicate_detection.pop(input_hash)
    if not return_to_log:
        for t in to_log_list:
            logger.info(t)
        return response_content
    else:
        return response_content, to_log_list


# sec MAIN


# sec 1. group&select data |fixed
sorted_funcs = []  # Executes the dataset in the order in which it is read
taskfunc2name = {}
taskfunc2items = {}
for item in corpus:
    cur_bbh_type = "perform the task: " + item["category"]
    if cur_bbh_type not in sorted_funcs:
        sorted_funcs.append(cur_bbh_type)
        taskfunc2name[cur_bbh_type] = item["category"]
    if cur_bbh_type not in taskfunc2items:
        taskfunc2items[cur_bbh_type] = []
    taskfunc2items[cur_bbh_type].append(item)

for ffid, func in enumerate(sorted_funcs):
    logger.info(f"{ffid} Examples: {len(taskfunc2items[func])}    Task Name: {taskfunc2name[func]}")
# all
logger.info("total task num: %d" % len(corpus))
logger.info("dataset: " + LOGDIR)

# sec build mem
to_mem_data = []

for task_id, func in tqdm(enumerate(sorted_funcs), desc=LOGDIR, total=len(sorted_funcs), bar_format=bar_format):
    logger.info("### START task %s %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items)))

    # sec find hard and easy
    hard_item_list = []
    easy_item_list = []
    futures = []
    zs_cot_prompt_ls = []

    with ThreadPoolExecutor(max_workers=1) as executor:
        for intask_item_id, item in tqdm(enumerate(taskfunc2items[func]), desc=taskfunc2name[func], total=len(taskfunc2items[func]), bar_format=bar_format):
            logger.info("### START task %s %d/%d  example %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items),
                                                                        intask_item_id + 1, len(taskfunc2items[func])))

            prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)
            zs_cot_prompt = """%s\nLet's think step by step.""" % (prompt.strip())
            zs_cot_prompt_ls.append(zs_cot_prompt)
            # repeat_time = 4
            # repeat_time = 4
            # repeat_time = 5
            # repeat_time = 3
            repeat_time = 2
            # repeat_time = 1
            # repeat_time = 1
            futures.append(
                executor.submit(task_reasoning_with_split_prompt_multip, chat_create, logger, logger_lock, valid_out_format, valid_out_answer,
                                zs_cot_prompt,
                                prompt_part2,
                                "zero-shot-cot", repeat_time=repeat_time,
                                is_empty_system=True,
                                is_answer_plus=True,
                                is_new_seed=False, return_ort=True)
            )

        results = [future.result() for future in futures]  # Block until all tasks are completed.
    assert len(results) == len(zs_cot_prompt_ls) == len(taskfunc2items[func])
    for item, (zero_shot_cot_tp, origin_response_text), zs_cot_prompt in zip(taskfunc2items[func], results, zs_cot_prompt_ls):
        if zero_shot_cot_tp == 0:
            assert type(origin_response_text) == str
            item["origin_response_text"] = origin_response_text
            item["zs_cot_prompt"] = zs_cot_prompt
            hard_item_list.append(item)
        else:
            easy_item_list.append(item)
    logger.info("cur_hard_num: %d" % len(hard_item_list))
    logger.info("cur_easy_num: %d" % len(easy_item_list))
    logger.info("### END hard easy split for task %s %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items)))

    # sec revise experience
    logger.info("### START experience generation for task %s %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items)))

    with ThreadPoolExecutor(max_workers=1) as executor:
        futures = []
        for intask_item_id, item in tqdm(enumerate(hard_item_list), desc="Exp Revise Gen", total=len(hard_item_list), bar_format=bar_format):
            logger.info("### START revise %s %d/%d ###" % ("hard", intask_item_id + 1, len(hard_item_list)))

            prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)
            cur_final_reasoning_prompt = item["zs_cot_prompt"]
            cur_response_text = item["origin_response_text"]
            # sec generate experience

            # max_revised_time = 2
            # max_revised_time = 6
            # max_revised_time = 5
            # max_revised_time = 8
            # max_revised_time = 100
            # max_revised_time = 25
            # max_revised_time = 50
            max_revised_time = 3
            # max_revised_time = 10
            # max_revised_time = 20
            # max_revised_time = 50
            #Different models may require different numbers of retries. For example, gpt4 requires significantly more retries, making it uneconomical to build on gpt4, compared to the improvement.

            revise_messages_list = [
                [{"role": "system", "content": ""},
                 {"role": "user", "content": cur_final_reasoning_prompt},
                 {"role": "assistant", "content": cur_response_text},
                 {"role": "user",
                  "content": """You are wrong. The correct answer is %s. Please give me the reasons why the correct answer is %s rather than your above answer. List by points.""" % (
                      prompt_answer, prompt_answer)}
                 ],

                [{"role": "user",
                  "content": """Please rewrite these reasons into concise insights, strategies or knowledge that can be provided to you in advance to help you avoid making the same mistakes next time. Each is an independent and concise insight, strategy or knowledge. List by points."""}],

                [{"role": "user", "content": "Be more general and concise. List by points."}]

            ]

            for revised_time in range(max_revised_time):
                futures.append(
                    executor.submit(experience_revise_with_messages_v2_multip, chat_create, logger, logger_lock, deepcopy(revise_messages_list),
                                    revised_time,
                                    max_revised_time))
        results = [future.result() for future in futures]
        assert len(results) == len(hard_item_list) * max_revised_time, (len(results), len(hard_item_list) * max_revised_time)
        all_hard_exps_li = []
        for tid in range(0, len(results), max_revised_time):
            cur_tmp_results = results[tid:tid + max_revised_time]
            all_hard_exps = list(set(list(itertools.chain(*cur_tmp_results))))
            all_hard_exps = sorted(all_hard_exps)
            random.shuffle(all_hard_exps)
            all_hard_exps_li.append(all_hard_exps)
        assert len(all_hard_exps_li) == len(hard_item_list)
        # sec check experience
        for intask_item_id, item in tqdm(enumerate(hard_item_list), desc="Exp Revise Check", total=len(hard_item_list), bar_format=bar_format):
            logger.info("### START revise %s %d/%d ###" % ("hard", intask_item_id + 1, len(hard_item_list)))
            prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)

            all_hard_exps = all_hard_exps_li[intask_item_id]

            # check_time = 1
            check_time = 3
            # check_time = 2
            # check_time = 4
            # check_time = 4
            # check_time = 5
            0
            with ThreadPoolExecutor(max_workers=1) as executor:
                futures = []
                for siid, single_insight in enumerate(all_hard_exps):
                    p_type = "check_per_rule_%d/%d" % (siid + 1, len(all_hard_exps))
                    final_reasoning_prompt = gen_exp_use_prompt_hard("- " + single_insight.strip(), prompt)
                    futures.append(
                        executor.submit(task_reasoning_with_split_prompt_multip, chat_create, logger, logger_lock, valid_out_format, valid_out_answer,
                                        final_reasoning_prompt,
                                        prompt_part2, p_type, repeat_time=check_time, is_empty_system=True,
                                        is_answer_plus=True,
                                        is_new_seed=False)
                    )
                results = [future.result() for future in futures]  # Block until all tasks are completed.
            success_experience = []
            assert len(results) == len(all_hard_exps)
            for raid, (check_acc_num_for_this_rule, single_insight) in enumerate(zip(results, all_hard_exps)):
                logger.info("check_acc_num_for_this_rule: " + str(check_acc_num_for_this_rule))
                if check_acc_num_for_this_rule == check_time:
                    success_experience.append(single_insight)

            logger.info("reasoning with revised experience, checked rules: %d/%d" % (len(success_experience), len(all_hard_exps)))
            logger.info("\nsuccess experience:\n" + "\n".join(["- " + ins for ins in success_experience]) +
                        "\nfailed experience:\n" + "\n".join(["- " + ins for ins in all_hard_exps if ins not in success_experience]))

            item["success_experience"] = success_experience
            item["is_success"] = len(success_experience) != 0
            logger.info("### END revise %s %d/%d ###" % ("hard", intask_item_id + 1, len(hard_item_list)))
            # pdb.set_trace()
    # End the Experience gather Phase
    logger.info("### END the revise of the experience ###")

    # sec gen task steps and func. tokenize them, prompt and insights.
    logger.info("### start gen stepfunc, tokenize of task %s %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items)))

    
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures = []
        for item in hard_item_list + easy_item_list:
            prompt = item_parser_with_split_prompt(item)[0]
            futures.append(executor.submit(gen_task_steps_multip, chat_create, logger, logger_lock, prompt))
            # futures.append(gen_task_steps_multip( chat_create, logger, logger_lock, prompt))
        results = [future.result() for future in futures]
    cur_task_steps_li = results

    
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures2 = []
        for cur_task_steps in cur_task_steps_li:
            futures2.append(executor.submit(nlp, "\n".join(cur_task_steps)))
    nlp_res = [future.result() for future in futures2]
    toked_task_steps_li = [[token.lemma_ for token in t if not token.is_stop] for t in nlp_res]

    
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures3 = []
        for item in hard_item_list + easy_item_list:
            futures3.append(executor.submit(nlp, item_parser_with_split_prompt(item)[0]))
    nlp_res2 = [future.result() for future in futures3]
    toked_prompt_li = [[token.lemma_ for token in t if not token.is_stop] for t in nlp_res2]

    
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures4 = []
        for item in hard_item_list + easy_item_list:
            prompt = item_parser_with_split_prompt(item)[0]
            futures4.append(executor.submit(gen_task_func_multip, chat_create, logger, logger_lock, prompt))
        results = [future.result() for future in futures4]
    cur_task_func_li = results

    
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures5 = []
        for cur_task_func in cur_task_func_li:
            futures5.append(executor.submit(nlp, cur_task_func))
    nlp_res3 = [future.result() for future in futures5]
    toked_task_func_li = [[token.lemma_ for token in t if not token.is_stop] for t in nlp_res3]

    assert len(toked_task_steps_li) == len(toked_prompt_li) == len(hard_item_list + easy_item_list) == len(toked_task_func_li) == len(
        cur_task_steps_li) == len(
        cur_task_func_li)
    for item, toked_task_steps, toked_prompt, toked_task_func, task_steps, task_func in zip(hard_item_list + easy_item_list, toked_task_steps_li,
                                                                                            toked_prompt_li, toked_task_func_li, cur_task_steps_li,
                                                                                            cur_task_func_li):
        item["toked_task_steps"] = toked_task_steps
        item["toked_prompt"] = toked_prompt
        item["toked_task_func"] = toked_task_func
        item["task_steps"] = task_steps
        item["task_func"] = task_func

    
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures6 = []
        visited_items = []
        for item in hard_item_list:
            if "is_success" in item and item["is_success"]:
                for t in item["success_experience"]:
                    visited_items.append(item)
                    futures6.append(executor.submit(nlp, t))
    nlp_res = [future.result() for future in futures6]
    toked_insights_li = [[token.lemma_ for token in t if not token.is_stop] for t in nlp_res]
    assert len(toked_insights_li) == len(visited_items)
    for toked_ins, item in zip(toked_insights_li, visited_items):
        if "toked_success_experience" not in item:
            item["toked_success_experience"] = []
        item["toked_success_experience"].append(toked_ins)
    for t in visited_items:
        assert len(t["toked_success_experience"]) == len(t["success_experience"])

    to_mem_data.append([task_id, func, taskfunc2name[func], len(hard_item_list + easy_item_list), hard_item_list, easy_item_list])

# sec end build or load  mem


is_forbid_parallel = False

# sec build index
for t in to_mem_data:
    for item in t[4]:
        item["cur_exm_task_id"] = t[0]  # Used to exclude data from the same dataset
    for item in t[5]:
        item["cur_exm_task_id"] = t[0]

toked_func_all_il = [item["toked_task_func"] for t in to_mem_data for item in t[4]] + [item["toked_task_func"] for t in to_mem_data for item in t[5]]
task_func_bm25 = BM25Okapi(toked_func_all_il)

toked_steps_all_il = [item["toked_task_steps"] for t in to_mem_data for item in t[4]] + [item["toked_task_steps"] for t in to_mem_data for item in t[5]]
task_steps_bm25 = BM25Okapi(toked_steps_all_il)

task_data_bm25 = [item for t in to_mem_data for item in t[4]] + [item for t in to_mem_data for item in t[5]]

# note
task_prompt_bm25 = BM25Okapi([item["toked_prompt"] for t in to_mem_data for item in t[4]] + [item["toked_prompt"] for t in to_mem_data for item in t[5]])

# note Replace BM25 with vector retrieval using faiss
is_use_faiss = False
if is_use_faiss:
    torch.set_grad_enabled(False)
    faiss_encoder = SentenceTransformer('sentence-transformers/all-mpnet-base-v2')
    task_func_faiss = {"vec": []}
    task_steps_faiss = {"vec": []}
    for item_index, item in tqdm(enumerate(task_data_bm25), desc="faiss encode", total=len(task_data_bm25), bar_format=bar_format):
        cur_item_func_vec = faiss_encoder.encode(item["task_func"])
        cur_item_steps_vec = faiss_encoder.encode("\n".join(item["task_steps"]))
        item["task_func_vec"] = cur_item_func_vec
        item["task_steps_vec"] = cur_item_steps_vec
        task_func_faiss["vec"].append(cur_item_func_vec)
        task_steps_faiss["vec"].append(cur_item_steps_vec)
    task_func_faiss = Dataset.from_dict(task_func_faiss)
    task_steps_faiss = Dataset.from_dict(task_steps_faiss)
    task_func_faiss = task_func_faiss.add_faiss_index(column='vec')
    task_steps_faiss = task_steps_faiss.add_faiss_index(column='vec')
    task_func_bm25 = task_func_faiss
    task_steps_bm25 = task_steps_faiss

# sec start test
acc_counter_list=[]
check_times_counter_list=[]
for task_id, func in tqdm(enumerate(sorted_funcs), desc=LOGDIR, total=len(sorted_funcs), bar_format=bar_format):
    logger.info("### START EXP TEST task %s %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items)))

    cur_md = to_mem_data[task_id]
    assert cur_md[0] == task_id
    assert cur_md[1] == func
    assert cur_md[2] == taskfunc2name[func]
    assert cur_md[3] == len(taskfunc2items[func])
    hard_item_list, easy_item_list = cur_md[4:6]

    acc_counter = {}
    ins_chage_counter = {}
    check_times_counter = {}
    diff_tp_counter = defaultdict(int)
    insightnum2acc = defaultdict(list)

    0
    with ThreadPoolExecutor(max_workers=1) as executor:
        futures = []
        for subtype, subtype_item_list in [("hard", hard_item_list), ("easy", easy_item_list)]:

            # Note: Transfer Source Selection
            tmpt_futures = []
            for intask_item_id, item in tqdm(enumerate(subtype_item_list), desc="Select Src" + subtype, total=len(subtype_item_list),
                                             bar_format=bar_format):
                logger.info("### START select src %s %d/%d ###" % (subtype, intask_item_id + 1, len(subtype_item_list)))
                prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)
                # For experience transfer, choosing the right source of transfer is of utmost importance.
                # task： bm25
                # step： bm25
                # Merge score: Merge two scores
                # If the top 10 at this point are all easy, meaning there is no experience, we believe that the example is too simple or difficult and does not require experience.
                # GPT: merge score select the top 10, use GPT for selection

                if is_forbid_parallel:
                    tmpt_futures.append(
                        exprience_bm25_select_multip_with_easy_new_formal(chat_create, logger, logger_lock, prompt, item, task_func_bm25,
                                                                          task_steps_bm25,
                                                                          task_data_bm25, task_prompt_bm25, select_example_num=10))
                else:
                    tmpt_futures.append(
                        executor.submit(
                            exprience_bm25_select_multip_with_easy_new_formal, chat_create, logger, logger_lock, prompt, item, task_func_bm25,
                            task_steps_bm25,
                            task_data_bm25, task_prompt_bm25, select_example_num=10))
            if is_forbid_parallel:
                select_bm25_insights = tmpt_futures
            else:
                select_bm25_insights = [future.result() for future in tmpt_futures]
            assert len(select_bm25_insights) == len(subtype_item_list)

            # Note migration experience
            tmp_futures = []
            for intask_item_id, item in tqdm(enumerate(subtype_item_list), desc="Refine Insights " + subtype, total=len(subtype_item_list),
                                             bar_format=bar_format):
                logger.info("### START get-refine-insights %s %d/%d ###" % (subtype, intask_item_id + 1, len(subtype_item_list)))
                prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)

                top_insights = select_bm25_insights[intask_item_id]
                if is_forbid_parallel:
                    tmp_futures.append(experience_transfer_and_evaluate_singlep_new_multip(nlp, item, chat_create, logger, logger_lock, prompt,
                                                                                           top_insights, top_n=5))
                                                                                           # top_insights, top_n=6))
                                                                                           # top_insights, top_n=7))
                                                                                           # top_insights, top_n=8))
                                                                                           # top_insights, top_n=9))
                                                                                           # top_insights, top_n=15))
                                                                                           # top_insights, top_n=12))
                                                                                           # top_insights, top_n=11))
                else:
                    tmp_futures.append(
                        executor.submit(experience_transfer_and_evaluate_singlep_new_multip, nlp, item, chat_create, logger, logger_lock, prompt,
                                        top_insights, top_n=5))
                                        # top_insights, top_n=6))
                                        # top_insights, top_n=7))
                                        # top_insights, top_n=8))
                                        # top_insights, top_n=9))
                                        # top_insights, top_n=15))
                                        # top_insights, top_n=12))
                                        # top_insights, top_n=11))
            if is_forbid_parallel:
                refined_insights_li = tmp_futures
            else:
                refined_insights_li = [future.result() for future in tmp_futures]
            assert len(refined_insights_li) == len(subtype_item_list)

            # note start verify
            for intask_item_id, item in tqdm(enumerate(subtype_item_list), desc="Verify " + subtype, total=len(subtype_item_list), bar_format=bar_format):

                logger.info("### START verify %s %d/%d ###" % (subtype, intask_item_id + 1, len(subtype_item_list)))
                prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer = item_parser_with_split_prompt(item)

                to_verify = []
                # to_verify.append(("zero-shot-cot", """%s\n\nLet's think step by step.""" % (prompt.strip())))
                # to_verify.append(("zero-shot", prompt.strip()))

                top_insights = refined_insights_li[intask_item_id]
                hard_experience_text = "\n".join(["- " + ins for ins in top_insights])
                to_verify.append(("reasoning_with_exp_all", gen_exp_use_prompt_soft(hard_experience_text, prompt.strip())))

                for p_type, final_reasoning_prompt in to_verify:
                    if p_type not in acc_counter:
                        acc_counter[p_type] = defaultdict(int)
                    if p_type not in check_times_counter:
                        check_times_counter[p_type] = defaultdict(int)
                    if p_type not in ins_chage_counter:
                        ins_chage_counter[p_type] = defaultdict(list)

                    check_time = 3
                    if is_forbid_parallel:
                        futures.append(
                            task_reasoning_with_split_prompt_multip(chat_create, logger, logger_lock, valid_out_format, valid_out_answer,
                                                                    final_reasoning_prompt,
                                                                    prompt_part2,
                                                                    p_type, repeat_time=check_time, is_empty_system=True, is_new_seed=True,
                                                                    is_answer_plus=True,
                                                                    other_info=(p_type, subtype, check_time,
                                                                                -1 if "success_experience" not in item else len(item["success_experience"]),
                                                                                len(top_insights) != 0
                                                                                )
                                                                    )
                        )
                    else:
                        futures.append(
                            executor.submit(task_reasoning_with_split_prompt_multip, chat_create, logger, logger_lock, valid_out_format, valid_out_answer,
                                            final_reasoning_prompt,
                                            prompt_part2,
                                            p_type, repeat_time=check_time, is_empty_system=True, is_new_seed=True, is_answer_plus=True,
                                            other_info=(p_type, subtype, check_time,
                                                        -1 if "success_experience" not in item else len(item["success_experience"]),
                                                        len(top_insights) != 0
                                                        )
                                            )
                        )
        if is_forbid_parallel:
            results = futures
        else:
            results = [future.result() for future in futures]
    for correct_num, (p_type, subtype, check_time, len_suc_exp, is_used_insights) in results:
        acc_counter[p_type][subtype] += correct_num
        check_times_counter[p_type][subtype] += check_time
        ins_chage_counter[p_type]["w/_ins" if is_used_insights else "w/o_ins"].append(correct_num)

        if p_type == "reasoning_with_exp_all":
            insightnum2acc[len_suc_exp].append(correct_num)

    logger.info("### verify all info of task %s %d/%d ###" % (taskfunc2name[func], task_id + 1, len(taskfunc2items)))

    acc_counter_list.append(deepcopy(acc_counter))
    check_times_counter_list.append(deepcopy(check_times_counter))



