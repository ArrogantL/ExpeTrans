# -*- coding: utf-8 -*-
import json
import re
import traceback
from concurrent.futures import ThreadPoolExecutor


def item_parser(item):
    prompt = item["prompt"]
    # reasoning with exp for user's query
    valid_out_answer = (item["prompt_answer_text"][0], item["prompt_answer"])
    valid_out_format = item["prompt_answer_text"][1]
    valid_out_format.extend(["yes", "no", "neutral", "a", "b", "c", "d", "e", "f"])
    valid_out_answer = [t.lower().strip() for t in valid_out_answer]
    valid_out_format = [t.lower().strip() for t in valid_out_format]
    for t in valid_out_answer:
        assert t in valid_out_format

    prompt_answer = item["prompt_answer"]

    prompt = prompt.strip()

    return prompt, valid_out_format, valid_out_answer, prompt_answer


def item_parser_with_split_prompt(item):
    prompt, valid_out_format, valid_out_answer, prompt_answer = item_parser(item)
    prompt_part1, prompt_part2 = pt_split = prompt.split("Use the following JSON format to output your answer:")
    assert len(pt_split) == 2
    prompt_part2 = "Convert the above origin answer into the following JSON format:" + prompt_part2
    prompt_part1 = prompt_part1.strip()
    prompt_part2 = prompt_part2.strip()



    prompt = prompt_part1

    return prompt, prompt_part2, valid_out_format, valid_out_answer, prompt_answer


def task_reasoning_with_split_prompt_multip(chat_create, logger, logger_lock, valid_out_format, valid_out_answer, prompt1, prompt2, prompt_name, repeat_time,
                                            is_empty_system,
                                            is_new_seed,
                                            is_answer_plus=False, max_retry=3, other_info=None, return_ort=False, debug_prompt=None):
    def sub_p(rtime):
        cur_all_to_log = []
        for i in range(max_retry + 1):
            if i == max_retry:
                cur_all_to_log.append("retry too many times")
                pred_label = "No correct answer"
                break
            try:
                model_type = "gpt-3.5-turbo-0125"

                cur_messages = [{"role": "system", "content": ""}] if is_empty_system else []
                cur_messages.append({"role": "user", "content": prompt1})

                tmp_rseed = 1000 if is_new_seed else 0
                response, to_log = chat_create(model=model_type, max_tokens=1024, seed=1 + i + tmp_rseed + rtime * 10000, temperature=1,
                                               messages=cur_messages,
                                               log_flag="%s time %d/%d retry %d/%d" % (prompt_name, rtime + 1, repeat_time, i + 1, max_retry),
                                               return_to_log=True)
                cur_all_to_log.extend(to_log)
                origin_response_text = response.strip()
                if not is_answer_plus:
                    cur_messages = [{"role": "user", "content": "<Origin Answer>\n" + response.strip() + "\n<\Origin Answer>\n\n" + prompt2}]
                else:
                    cur_messages = [{"role": "user", "content": "<Question>\n%s\n<\Question>\n<Origin Answer>\n%s\n<\Origin Answer>\n\n" % (
                        prompt1.strip() if debug_prompt is None else debug_prompt, response.strip()) + prompt2}]

                response, to_log = chat_create(model=model_type, max_tokens=1024, seed=1 + i + tmp_rseed + rtime * 10000, temperature=1,
                                               messages=cur_messages,
                                               log_flag="%s-formatting time %d/%d retry %d/%d" % (
                                                   prompt_name, rtime + 1, repeat_time, i + 1, max_retry),
                                               return_to_log=True)
                cur_all_to_log.extend(to_log)

                res = re.findall("```json(.*?)```", response, flags=re.S)
                if len(res) == 0:
                    res = re.findall(r"(\{.*?})", response, flags=re.S)
                tmp_out = list(json.loads(res[0]).values())
                pred_label = None
                for t in tmp_out:
                    t = t.lower().strip()
                    if t in valid_out_format:
                        pred_label = t
                        break
                assert pred_label is not None
                break
            except (AttributeError, json.decoder.JSONDecodeError, AssertionError):
                cur_all_to_log.append("retry %d/%d" % (i + 1, max_retry))
                cur_all_to_log.append(traceback.format_exc())
                pred_label = None
            except Exception:
                cur_all_to_log.append("retry %d/%d" % (i + 1, max_retry))
                cur_all_to_log.append(traceback.format_exc())
                with logger_lock:
                    for t in all_to_log:
                        logger.info(t)
                assert False

        cur_all_to_log.append("pred_label: %s  valid_out_answer: %s" % (pred_label, valid_out_answer))
        is_correct = int(pred_label in valid_out_answer)
        return cur_all_to_log, origin_response_text, is_correct

    if repeat_time == 0:
        assert False

    zero_shot_tp = 0
    all_to_log = []
    final_ort = None
    with ThreadPoolExecutor(max_workers=repeat_time) as executor:
        futures = []
        for rtime in range(repeat_time):
            futures.append(executor.submit(sub_p, rtime))

        results = [future.result() for future in futures]

        for res in results:
            cur_all_to_log, ort, is_correct = res
            if is_correct == 0:
                final_ort = ort
            all_to_log.extend(cur_all_to_log)
            zero_shot_tp += is_correct

    with logger_lock:
        for t in all_to_log:
            logger.info(t)

    if other_info is None:
        if not return_ort:
            return zero_shot_tp
        else:
            return zero_shot_tp, final_ort
    else:
        if not return_ort:
            return zero_shot_tp, other_info
        else:
            return zero_shot_tp, final_ort, other_info
